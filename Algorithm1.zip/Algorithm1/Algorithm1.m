%Program of Steganography Using LSB substitution%

clc;
clear all;
close all;

cover = input('Enter cover image: ', 's');
message = input('Enter message image name: ', 's');

X = imread(cover);
Y = imread(message);
[x_1, y_1, z_1] = size(X);
[x_2, y_2, z_2] = size(Y);

if (x_1 >= x_2)
    final_x = x_1;
else 
    final_x = x_2;
end

if (y_1 >= y_2)
    final_y = y_1;
else 
    final_y = y_2;
end

var1 = ceil((final_x-x_1) / 2);
var2 = ceil((final_y-y_1) / 2);
var3 = ceil((final_x-x_2) / 2);
var4 = ceil((final_y-y_2) / 2);
A = padarray(X, [var1, var2],0, 'both');
B = padarray(Y, [var3, var4],0, 'both');
[size1, size2, useless1] = size(A);
[size3, size4, useless2] = size(B);


if (size1 < size3)
    B(size3,:,:) = [];
end
if (size1 > size3)
    A(size1,:,:) = [];
end

if (size2 < size4)
    B(:,size4,:) = [];
end
if (size2 > size4)
    A(:,size2,:) = [];
end
    


imwrite(A, 'temp1.png')
imwrite(B, 'temp2.png')

%I1=imread(cover);%
%I2 = imresize(I1,[final_x final_y]); %
%In=rgb2gray(I2); % use if the image containing RGB value 3%
%figure;imshow(In);%
%imwrite(I2,cover);%

%I1=imread(message);%
%I2 = imresize(I1,[final_x final_y]); %
%In=rgb2gray(I2); % use if the image containing RGB value 3%
%figure;imshow(In);%
%imwrite(I2,message) ;% 

x = imread('temp1.png');         % cover message
y = imread('temp2.png');    % message image
n = 4; %input('Enter the no of LSB bits to be subsituted- '); %

S = uint8(bitor(bitand(x,bitcmp(2^n-1, 'uint8')),bitshift(y,n-8))); %Stego
E = uint8(bitand(255,bitshift(S,8-n))); %Extracted



origImg = double(x);   %cover image
distImg = double(S);   %stego image

[M N] = size(origImg);
distImg1=imresize(distImg,[final_x final_y]);
error = origImg - distImg1;
MSE = sum(sum(error .* error)) / (M * N);
if(MSE > 0)
    PSNR = 10*log10(M*N./MSE);
else
    PSNR = 99;
end
disp('PSNR of message image to extracted image is')
disp(abs(PSNR))
disp('MSE is')
disp(abs(MSE))


figure(1),imshow(X);title('1.Cover image')
figure(2),imshow(Y);title('2.Message to be hide')
figure(3),imshow((abs(S)),[]);title('3.Steganographic image')
figure(4),imshow(real(E),[]); title('4.Extracted image')

figure(5),imhist(x); title('Histogram of cover image')
figure(6),imhist(S); title('Histogram of transformed stego image')

imwrite(S, 'Stegoimage.png');
imwrite(E, 'Extracted.png');
