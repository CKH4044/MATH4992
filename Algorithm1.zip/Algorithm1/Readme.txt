This program is the algorithm 1 described in the report. This program can only merge two QR codes together. 

The program is modified from the source code in MathWorks "Steganography using LSB substitution" by Ashish Soni https://www.mathworks.com/matlabcentral/fileexchange/41326-steganography-using-lsb-substitution 
so that the program we are showing is error-free. Work for every cases such as different dimensions or different color models of two images.


Demo of the program:

Enter cover image: test1_BW.png
Enter message image name: test2_colored.png

Then you can get the MSE and PSNR values. 
Also, we will show you the 
1. Cover image, 
2. Meessage to be hidden
3. Steganographic image
4. Extracted image
5. Histogram of Cover image
6. Histogram of transformed stego image

The stego image will then be updated to the "Stegoimage.png"
and the extracted secret image will be updated to the "Extracted.png". 