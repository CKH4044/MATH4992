Remark: Program will modify the original QR codes in the current directory. Therefore, if you want to use the same set of QR codes again, you need to delete all QR codes in the current directory. Then copy original QR codes again to the current directory.  

For example, you run 
>>hide_image('google.png', 'matlab.png', 'qr.jpg', 'abc.png', 'test1.png', 'test2.png', 'test3.png');
>>extract_image('embedded.png');

If you want to test the same QR codes again, 
>>hide_image('google.png', 'matlab.png', 'qr.jpg', 'abc.png', 'test1.png', 'test2.png', 'test3.png');
>>extract_image('embedded.png');

Before you do so, you need to delete the QR codes 'google.png', 'matlab.png', 'qr.jpg', 'abc.png', test1.png', 'test2.png', 'test3.png'in the current directory. Then, copy the QR codes 'google.png', 'matlab.png', 'qr.jpg', 'abc.png', test1.png', 'test2.png', 'test3.png' in the file '7 test cases' and paste it to the current directory.
Otherwise, you will get wrong PSNR and MSE results, and also get some problems.
------------------------------------------------------------------------------------------------

The program is the advanced algorithm 2 in the report. 

The program is modified from Hide Images In Image in "MathWorks" by Divakar Roy. https://www.mathworks.com/matlabcentral/fileexchange/26217-hide-images-in-image

so that the modified program will not have as many restrictions as the source codes. And, the program can run for QR codes QR codes combined after modification. Also, the modified program can work for every type of QR codes for different dimensions, different color models.


For demo purposes, run:
we first need to embed different QR codes inside a QR code Cover image. In the example, the Cover image QR code is 'google.png'. All the QR code after the 'google.png' will be the QR codes Secret images. 
>> hide_image('google.png', 'matlab.png', 'qr.jpg', 'abc.png', 'test1.png', 'test2.png', 'test3.png');

We will show you the histogram of Cover image and Histogram of transformed stego image
After the above command, we will get the 'embedded.png' in the same directory. The 'embedded.png' is the final stego-image for steganography.

If you want to extract the QR codes Secret images from the stego-image QR code 'embedded.png'. You can call
>> extract_image('embedded.png');
>> 6 Image(s) extracted by the name(s) 'extracted(1..).png' in the current directory.

In the current directory, there will be 6 png file named as 'extracted1.png', 'extracted2.png', ... 'extracted6.png'. They are the extracted Secret images.





