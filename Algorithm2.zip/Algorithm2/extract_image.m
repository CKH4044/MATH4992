function extract_image(source_image)


a=double(imread(source_image));
a1=reshape(a,1,size(a,1)*size(a,2)*size(a,3));
a2=rem([a1 zeros(1,8-rem(length(a1),8))],2);
a11=reshape(a2,8,length(a2)/8);
num_of_images=sum(a11(:,1).*power(2,0:7)');
for i=1:num_of_images
    x=4*i-2;
szim(i,1)=sum([a11(2:end,x) ; a11(:,x+1)].*power(2,0:14)');
szim(i,2)=sum([a11(:,x+2) ; a11(:,x+3)].*power(2,0:15)');
szim(i,3)=a11(1,x)*2+1;
end
next=4*num_of_images+1;
for j=1:num_of_images
a22=zeros(1,szim(j,1)*szim(j,2)*szim(j,3));
for i=1:szim(j,1)*szim(j,2)*szim(j,3)
a22(i)=sum(a11(:,i+next).*power(2,0:7)');
end
a33=reshape(a22,szim(j,1),szim(j,2),szim(j,3));
outout_img_filename=['extracted' num2str(j) '.png']; 
imwrite(uint8(a33),outout_img_filename);
next=next+szim(j,1)*szim(j,2)*szim(j,3);
end
display_text=[num2str(num_of_images) ' Image(s) extracted by the name(s) ''extracted(1..).png'' in the current directory.'];
disp(display_text);