function hide_image(src_img,varargin)

%---------- Inputs---------------------------------------------------------
cover = src_img;
tempX = imread(cover);
num_of_images=nargin-1;
all_images=[];
image1props=[];
szim=zeros(num_of_images,3);
check_limit=0;

temp = imread(src_img);
temp1 = imresize(temp, [180, 180]);
[size1, size2, ~] = size(temp1);
Y = uint8(zeros(size1, size2, 3));
temp1 = bitor(temp1, Y);
imwrite(temp1, src_img);
for i=1:num_of_images
    b = imread(char(varargin(i)));
    b1 = imresize(b, [90,90]);
    imwrite(b1, char(varargin(i)))
    secret = imread(char(varargin(i)));
    cover = imread(src_img);
    [x,y,z] = size(secret);
    [a,b,c] = size(cover);
    temp_2 = imresize(cover, [x+a, y+b]);
    imwrite(temp_2, src_img);
    
end

for i=1:num_of_images
    b=double(imread(char(varargin(i))));
    szim(i,1)=size(b,1);szim(i,2)=size(b,2);szim(i,3)=size(b,3);
    check_limit=check_limit+size(b,1)*size(b,2)*size(b,3);
    all_images=[all_images reshape(b,1,size(b,1)*size(b,2)*size(b,3))];
end
for i=1:num_of_images
    image1props=[image1props reshape([floor(szim(i,3)/3) binary_vector(szim(i,1))' zeros(1,15-length(binary_vector(szim(i,1)))) binary_vector(szim(i,2))' zeros(1,16-length(binary_vector(szim(i,2))))],8,4)];
end
next=4*num_of_images+1;
%--------------------------------------------------------------------------
a=double(imread(src_img));
percent_of_img_used=(100*8*(check_limit+4*num_of_images+1))/(size(a,1)*size(a,2)*size(a,3));
if percent_of_img_used >100
    display_text=['Too Many Images or Too Big Image for Hiding [Used ' num2str(percent_of_img_used) ' percent of the source image].'];
    error(display_text);
end
display_text = ['Used ' num2str(percent_of_img_used) ' percent of the source image. Embedded Image saved as : ''embedded.png'' in the current directory.'];
disp(display_text);

a2=[reshape(a,1,size(a,1)*size(a,2)*size(a,3)) zeros(1,8-rem(size(a,1)*size(a,2)*size(a,3),8))];
a11=2.*floor(reshape(a2,8,length(a2)/8)/2);
a11(:,1)=a11(:,1) + binary_vector(num_of_images);
a11(:,2:next)=a11(:,2:next) + image1props;
for j=1:num_of_images
    b1=all_images(next-4*num_of_images:next-4*num_of_images-1+szim(j,1)*szim(j,2)*szim(j,3));
    for i=1:length(b1)
        a11(:,i+next)=a11(:,i+next)+ binary_vector(b1(i));
    end
    next=next+szim(j,1)*szim(j,2)*szim(j,3);
end
a111=reshape(a11,1,size(a11,1)*size(a11,2)*size(a11,3));
a111=a111(1:end-(8-rem(size(a,1)*size(a,2)*size(a,3),8)));
a22=reshape(a111,size(a,1),size(a,2),size(a,3));

origImg = double(tempX);   %cover image
distImg = double(a22);   %stego image

[M, N, B] = size(origImg);
[A, B, ~] = size(distImg);

distImg1 = imresize(distImg, [M N]);

error = origImg - distImg1;
MSE = sum(sum(error .* error)) / (M * N);

if(MSE > 0)
    PSNR = 20*log10(M * N./MSE);
else
    PSNR = 99;
end
disp('PSNR of message image to extracted image is')
disp(abs(PSNR))
disp('MSE is')
disp(abs(MSE))

f=figure;
figure(1),imhist(tempX); title('Histogram of cover image')
saveas(f, 'cover_img.png');
f2 = figure;
figure(2),imhist(uint8(a22)); title('Histogram of transformed stego image')
saveas(f2, 'steg_img.png');


imwrite(uint8(a22),'embedded.png');

%--------------------------------------------------------------------------

function out = binary_vector(in)
% This code converts unsigned integer number into Binary vector.
% It is used in this project for conversion into binary numbers of 8-bit unsigned pixel values, 
% row, column and color information and also the number of images.
%
% Syntax:
% binary_vector(unsigned_integer_number)
%
% Example:
%
% >> binary_vector(234)
% 
% ans =
% 
%      0
%      1
%      0
%      1
%      0
%      1
%      1
%      1

out=zeros(8,1);
if ~in
    return;
else
    while(1)
        out(floor(log2(in))+1)=1;
        in= in - power(2,floor(log2(in)));
        if ~in
            break;end
    end
end


